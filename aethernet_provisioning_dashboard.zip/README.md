
# AetherNet Provisioning Dashboard

This is a React prototype for the AetherNet SIM provisioning and management dashboard.

## Features

- Provision Nano SIM or eSIM profiles
- Bind devices (AetherPhone or AetherGlasses) to SIM profiles
- Multi-factor authentication settings (biometric, YubiKey, voice lock)
- Network settings including Ghost Mode, Starlink fallback, and region locking

## Getting Started

1. Clone this repository
2. Install dependencies:

```bash
npm install
```

3. Run the development server:

```bash
npm run dev
```

4. Open [http://localhost:3000](http://localhost:3000) to view in your browser.

## Deployment

You can deploy this app easily using Vercel or Netlify:

- Push to GitHub
- Connect your repository to Vercel or Netlify
- Use default React build settings (`npm run build` and output folder `build/`)

## Notes

- This is a UI prototype. Backend API integration is required for full functionality.
- UI uses TailwindCSS for styling and lucide-react icons.

