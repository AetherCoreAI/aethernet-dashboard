
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Switch } from "@/components/ui/switch";
import { BadgeCheck, KeyRound, ShieldCheck, SatelliteDish } from "lucide-react";

export default function AetherNetProvisioning() {
  return (
    <div className="p-6 max-w-5xl mx-auto">
      <h1 className="text-3xl font-bold mb-4 text-center">AetherNet Provisioning Dashboard</h1>
      <Tabs defaultValue="provision" className="w-full">
        <TabsList className="grid grid-cols-4 mb-6">
          <TabsTrigger value="provision">Provision SIM</TabsTrigger>
          <TabsTrigger value="bind">Bind Device</TabsTrigger>
          <TabsTrigger value="auth">Multi-Factor Auth</TabsTrigger>
          <TabsTrigger value="network">Network Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="provision">
          <Card>
            <CardContent className="space-y-4 p-6">
              <Label htmlFor="simType">SIM Type</Label>
              <select id="simType" className="w-full border p-2 rounded-md">
                <option value="physical">Nano SIM</option>
                <option value="esim">eSIM (QR Code)</option>
              </select>
              <Label htmlFor="profile">Encryption Profile</Label>
              <Input id="profile" placeholder="Enter profile ID (auto-generated)" />
              <Button className="mt-2">Generate SIM Profile</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bind">
          <Card>
            <CardContent className="space-y-4 p-6">
              <Label htmlFor="deviceId">Device Serial Number</Label>
              <Input id="deviceId" placeholder="Enter AetherPhone or AetherGlasses ID" />
              <Label htmlFor="simId">SIM Profile ID</Label>
              <Input id="simId" placeholder="Link to existing SIM" />
              <Button className="mt-2">Bind Device</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="auth">
          <Card>
            <CardContent className="space-y-4 p-6">
              <Label>Enable Biometric Access</Label>
              <Switch />
              <Label>Enable YubiKey Requirement</Label>
              <Switch />
              <Label>Voice Command Lock Phrase</Label>
              <Input placeholder="e.g., 'Aether Lockdown'" />
              <Button className="mt-2">Save MFA Settings</Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="network">
          <Card>
            <CardContent className="space-y-4 p-6">
              <Label>Ghost Mode (Hide IMSI/IP)</Label>
              <Switch />
              <Label>Enable Starlink VOIP Fallback</Label>
              <Switch />
              <Label>Region Lock</Label>
              <select className="w-full border p-2 rounded-md">
                <option>Global Access</option>
                <option>US Only</option>
                <option>EU Only</option>
                <option>Custom Region</option>
              </select>
              <Button className="mt-2">Apply Network Settings</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
